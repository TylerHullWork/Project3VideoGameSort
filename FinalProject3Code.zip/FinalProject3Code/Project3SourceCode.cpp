// CSV Test.cpp : This file contains the 'main' function. Program execution begins and ends there.
// This program uses the CSV Library. See csv.hpp.

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <chrono>
#include <sstream>
#include <queue>
#include "csv.hpp"
using namespace std;
using namespace chrono;
using namespace csv;




struct game {
    string appID;
    string name;
    string releaseDate;
    string estimatedPlayers;
    string price;
    string description;
    vector<string> supportedLanguages;
    string windowsCompatible;
    string macCompatible;
    string linuxCompatible;
    string positiveReviews;
    string negativeReviews;
    string achievements;
    string recommendations;
    vector<string> developers;
    vector<string> genres;
    vector<string> tags;
    game* heapLeft;
    game* heaRight;

    game(string _appID, string _name, string _releaseDate, string _estimatedPlayers, string _price, string _description, string _windowsCompaitble, string _macCompatible, string _linuxCompatible, string _positiveReviews, string _negativeReviews, string _achievements, string _recommendations, vector<string> _supportedLanguages, vector<string> _developers, vector<string> _genres, vector<string> _tags) {
        appID = _appID; //Initialize all Variables on Creation
        name = _name;
        releaseDate = _releaseDate;
        estimatedPlayers = _estimatedPlayers;
        price = _price;
        description = _description;
        windowsCompatible = _windowsCompaitble;
        macCompatible = _macCompatible;
        linuxCompatible = _linuxCompatible;
        positiveReviews = _positiveReviews;
        negativeReviews = _negativeReviews;
        achievements = _achievements;
        recommendations = _recommendations;
        supportedLanguages = _supportedLanguages;
        developers = _developers;
        genres = _genres;
        tags = _tags;
    }

    game(){ //Default Constructor just in case
        appID = -1;
        name = "Not Provided";
    }
   
    void display() {
        cout << "Steam App ID: " << appID << endl << "Name: " << name << endl << "Released: " << releaseDate << endl;   //Display all facts about the game
        cout << "Estimated Players: " << estimatedPlayers << endl << "Price: " << price << endl;
        cout << "Description: " << description << endl;
        cout << "Compatibilities: " << "Windows: " << windowsCompatible << " Mac: " << macCompatible << " Linux: " << linuxCompatible << endl;
        cout << "Reviews: Positive " << positiveReviews << ", Negative " << negativeReviews << endl;
        cout << "Total Achievements: " << achievements << endl << "Recommendations: " << recommendations << endl;
        cout << "Supported Languages: ";
        for (int i = 0; i < supportedLanguages.size(); i++) {   //Print Supported Languages
            if (i != supportedLanguages.size()-1) {
                cout << supportedLanguages.at(i) << ", ";
            }
            else {
                cout << supportedLanguages.at(i) << endl;
            }
        }

        cout << "Developers: ";
        for (int i = 0; i < developers.size(); i++) {   //Print Developers
            if (i != developers.size() - 1) {
                cout << developers.at(i) << ", ";
            }
            else {
                cout << developers.at(i) << endl;
            }
        }
        
        cout << "Genres: ";
        for (int i = 0; i < genres.size(); i++) {   //Print Genres
            if (i != genres.size() - 1) {
                cout << genres.at(i) << ", ";
            }
            else {
                cout << genres.at(i) << endl;
            }
        }
        
        cout << "Tags: ";
        for (int i = 0; i < tags.size(); i++) {   //Print Tags
            if (i != tags.size() - 1) {
                cout << tags.at(i) << ", ";
            }
            else {
                cout << tags.at(i) << endl;
            }
        }

    }




};

class Splaytree   //Splay Tree class
{
private:
    struct splayNode      //private structure for treenodes
    {
        int ID;
        string NAME;
        game gameNode;
        splayNode* leftchild;
        splayNode* rightchild;
        splayNode* parent;
        splayNode(splayNode* parent, string appID, string name, string releaseDate, string estimatedPlayers, string price, string description, vector<string> supportedLanguages, string windowsCompatible, string macCompatible, string linuxCompatible, string positiveReviews, string negativeReviews, string achievements, string recommendations, vector<string> developers, vector<string> genres, vector<string> tags) {
            ID = stoi(appID);
            NAME = name;
            leftchild = nullptr;
            rightchild = nullptr;
            this->parent = parent;
            gameNode = game(appID, name, releaseDate, estimatedPlayers, price, description, windowsCompatible, macCompatible, linuxCompatible, positiveReviews, negativeReviews, achievements, recommendations, supportedLanguages, developers, genres, tags);
        }

    };
    splayNode* root = nullptr;


    Splaytree::splayNode* helperInsert(splayNode*& Splayer, splayNode* parent, splayNode* helpRoot, string appID, string name,
        string releaseDate,
        string estimatedPlayers,
        string price,
        string description,
        vector<string> supportedLanguages,
        string windowsCompatible,
        string macCompatible,
        string linuxCompatible,
        string positiveReviews,
        string negativeReviews,
        string achievements,
        string recommendations,
        vector<string> developers,
        vector<string> genres,
        vector<string> tags);

    void helperInorder(splayNode* helpRoot, bool& comma);
    void helperPreorder(splayNode* helpRoot);
    void helperPostorder(splayNode* helpRoot);

    bool Namesearchhelp(string nombre, splayNode* helpRoot);
    void SearchIDhelp(int key, splayNode* helpRoot);
    int LevelCounterhelp(splayNode* helpRoot);

    Splaytree::splayNode* Searchpredecessor(int key, splayNode* helpRoot);

    splayNode* Getnearleftmost(splayNode* helpRoot) {       //this function is used in unique circumstances where I need the node before the leftmost node
        if (helpRoot->leftchild == nullptr) {
            return helpRoot;
        }
        if (helpRoot->leftchild->leftchild == nullptr) {
            return helpRoot;
        }
        return Getnearleftmost(helpRoot->leftchild);
    }
    splayNode* Getrightmost(splayNode* helpRoot) {
        if (helpRoot->rightchild == nullptr) {
            return helpRoot;
        }
        return helpRoot->rightchild;
    }

    void Inordertraversal(splayNode* helpRoot, int N, int& counter, int& IDresult);


    splayNode* Zig(splayNode* parent);
    splayNode* Zag(splayNode* parent);

    void Destroyer(splayNode* helpRoot);
    Splaytree::splayNode* Splay(splayNode* helpRoot);

    vector<splayNode*> TagSearcher(vector<string> tags) {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = TagHelp(tags, splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> TagHelp(vector<string> Tags, queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        int counter = Tags.size();
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            int count = 0;
            for (int i = 0; i < searcher.front()->gameNode.tags.size(); i++) {
                for (int j = 0; j < Tags.size(); j++) {
                    if (searcher.front()->gameNode.tags[i] == Tags[j]) {
                        count += 1;
                        break;
                    }
                }
            }
            if (count == counter) {
                returnal.push_back(searcher.front());
                splayer.push(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }

    vector<splayNode*> GenreSearch(vector<string> genres) {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = GenreHelp(genres, splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> GenreHelp(vector<string> Genres, queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        int counter = Genres.size();
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            int count = 0;
            for (int i = 0; i < searcher.front()->gameNode.genres.size(); i++) {
                for (int j = 0; j < Genres.size(); j++) {
                    if (searcher.front()->gameNode.genres[i] == Genres[j]) {
                        count += 1;
                        break;
                    }
                }
            }
            if (count == counter) {
                returnal.push_back(searcher.front());
                splayer.push(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }

    vector<splayNode*> DeveloperSearch(vector<string> developers) {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = DeveloperHelp(developers, splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> DeveloperHelp(vector<string> developers, queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        int counter = developers.size();
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            int count = 0;
            for (int i = 0; i < searcher.front()->gameNode.developers.size(); i++) {
                for (int j = 0; j < developers.size(); j++) {
                    if (searcher.front()->gameNode.developers[i] == developers[j]) {
                        count += 1;
                        break;
                    }
                }
            }
            if (count == counter) {
                returnal.push_back(searcher.front());
                splayer.push(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }



    vector<splayNode*> WindowsSearch() {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = WindowsHelp(splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> WindowsHelp(queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            if (searcher.front()->gameNode.windowsCompatible == "TRUE") {
                returnal.push_back(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }

    vector<splayNode*> LinuxSearch() {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = LinuxHelp(splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> LinuxHelp(queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            if (searcher.front()->gameNode.linuxCompatible == "TRUE") {
                returnal.push_back(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }

    vector<splayNode*> MacSearch() {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = MacHelp(splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> MacHelp(queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            if (searcher.front()->gameNode.macCompatible == "TRUE") {
                returnal.push_back(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }



    vector<splayNode*> PriceRangeSearch(float pricelow, float pricehigh) {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = PriceRangeHelp(pricelow, pricehigh, splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> PriceRangeHelp(float pricelow, float pricehigh, queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            if ((stof(searcher.front()->gameNode.price) <= pricehigh) and (stof(searcher.front()->gameNode.price) >= pricelow)) {
                returnal.push_back(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }


    vector<splayNode*> PriceGreaterSearch(float pricelow) {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = PriceGreaterHelp(pricelow, splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> PriceGreaterHelp(float pricelow, queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            if ((stof(searcher.front()->gameNode.price) >= pricelow)) {
                returnal.push_back(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }

    vector<splayNode*> PriceLesserSearch(float pricehigh) {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = PriceLesserHelp(pricehigh, splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> PriceLesserHelp(float pricehigh, queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            if ((stof(searcher.front()->gameNode.price) >= pricehigh)) {
                returnal.push_back(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }


    vector<splayNode*> AchievementSearch() {
        vector<splayNode*> returnal;
        queue<splayNode*> splay;
        returnal = AchievementHelp(splay);
        while (!splay.empty()) {
            this->root = Splay(splay.front());
            splay.pop();
        }
        return returnal;
    }

    vector<splayNode*> AchievementHelp(queue<splayNode*>& splayer) {
        queue<splayNode*> searcher;
        searcher.push(this->root);
        vector<splayNode*> returnal;
        while (!searcher.empty()) {
            if (searcher.front()->gameNode.achievements != "0") {
                returnal.push_back(searcher.front());
            }
            if (searcher.front()->leftchild != nullptr) {
                searcher.push(searcher.front()->leftchild);
            }
            if (searcher.front()->rightchild != nullptr) {
                searcher.push(searcher.front()->rightchild);
            }
            searcher.pop();
        }
        return returnal;
    }

public:

    vector<game> FinalSearcher(vector<string> tags, vector<string> genres, vector<string> developers, bool windows, bool linux, bool mac, const string pricelow, const string pricehigh, bool achievements) {
        vector<splayNode*> finalnodes;
        if (!tags.empty()) {
            finalnodes = TagSearcher(tags);
        }
        if (!genres.empty()) {
            if (finalnodes.empty()) {
                finalnodes = GenreSearch(genres);
            }
            else {
                vector<splayNode*> NeoFinal;
                int counter = genres.size();
                for (int i = 0; i < finalnodes.size(); i++) {
                    int count = 0;
                    for (int k = 0; k < finalnodes[i]->gameNode.genres.size(); k++)
                        for (int j = 0; j < genres.size(); j++) {
                            if (finalnodes[i]->gameNode.genres[k] == genres[j]) {
                                count += 1;
                                break;
                            }
                        }
                    if (count == counter) {
                        NeoFinal.push_back(finalnodes[i]);
                    }
                }
                finalnodes = NeoFinal;
                for (int i = 0; i < finalnodes.size(); i++) {
                    this->root = Splay(finalnodes[i]);
                }
            }
        }



        if (!developers.empty()) {
            if (finalnodes.empty()) {
                finalnodes = DeveloperSearch(developers);
            }
            else {
                vector<splayNode*> NeoFinal;
                int counter = developers.size();
                for (int i = 0; i < finalnodes.size(); i++) {
                    int count = 0;
                    for (int k = 0; k < finalnodes[i]->gameNode.developers.size(); k++)
                        for (int j = 0; j < developers.size(); j++) {
                            if (finalnodes[i]->gameNode.developers[k] == genres[j]) {
                                count += 1;
                                break;
                            }
                        }
                    if (count == counter) {
                        NeoFinal.push_back(finalnodes[i]);
                    }
                }
                finalnodes = NeoFinal;
                for (int i = 0; i < finalnodes.size(); i++) {
                    this->root = Splay(finalnodes[i]);
                }
            }
        }


        if (windows) {
            vector<splayNode*> NeoFinal;
            if (finalnodes.empty()) {
                finalnodes = WindowsSearch();
            }
            else {
                for (int i = 0; i < finalnodes.size(); i++) {
                    if (finalnodes[i]->gameNode.windowsCompatible == "TRUE") {
                        NeoFinal.push_back(finalnodes[i]);
                    }
                }
                finalnodes = NeoFinal;
                for (int i = 0; i < finalnodes.size(); i++) {
                    this->root = Splay(finalnodes[i]);
                }
            }
        }


        if (linux) {
            vector<splayNode*> NeoFinal;
            if (finalnodes.empty()) {
                finalnodes = LinuxSearch();
            }
            else {
                for (int i = 0; i < finalnodes.size(); i++) {
                    if (finalnodes[i]->gameNode.linuxCompatible == "TRUE") {
                        NeoFinal.push_back(finalnodes[i]);
                    }
                }
                finalnodes = NeoFinal;
                for (int i = 0; i < finalnodes.size(); i++) {
                    this->root = Splay(finalnodes[i]);
                }
            }
        }



        if (mac) {
            vector<splayNode*> NeoFinal;
            if (finalnodes.empty()) {
                finalnodes = MacSearch();
            }
            else {
                for (int i = 0; i < finalnodes.size(); i++) {
                    if (finalnodes[i]->gameNode.macCompatible == "TRUE") {
                        NeoFinal.push_back(finalnodes[i]);
                    }
                }
                finalnodes = NeoFinal;
                for (int i = 0; i < finalnodes.size(); i++) {
                    this->root = Splay(finalnodes[i]);
                }
            }
        }




        if (pricelow != "" or pricehigh != "") {
            vector<splayNode*> NeoFinal;
            if (pricelow != "" and pricehigh != "") {       //Price Range
                float lowball = stof(pricelow);
                float highball = stof(pricehigh);
                if (finalnodes.empty()) {
                    finalnodes = PriceRangeSearch(lowball, highball);
                }
                else {
                    for (int i = 0; i < finalnodes.size(); i++) {
                        if ((stof(finalnodes[i]->gameNode.price) <= highball) and (stof(finalnodes[i]->gameNode.price) >= lowball)) {
                            NeoFinal.push_back(finalnodes[i]);
                        }
                    }
                    finalnodes = NeoFinal;
                    for (int i = 0; i < finalnodes.size(); i++) {
                        this->root = Splay(finalnodes[i]);
                    }
                }
            }
            else if (pricelow != "") {          // Greater than a certain price
                float lowball = stof(pricelow);
                if (finalnodes.empty()) {
                    finalnodes = PriceGreaterSearch(lowball);
                }
                else {
                    for (int i = 0; i < finalnodes.size(); i++) {
                        if ((stof(finalnodes[i]->gameNode.price) >= lowball)) {
                            NeoFinal.push_back(finalnodes[i]);
                        }
                    }
                    finalnodes = NeoFinal;
                    for (int i = 0; i < finalnodes.size(); i++) {
                        this->root = Splay(finalnodes[i]);
                    }
                }
            }
            else {  //Less than a certain price
                float highball = stof(pricehigh);
                if (finalnodes.empty()) {
                    finalnodes = PriceLesserSearch(highball);
                }
                else {
                    for (int i = 0; i < finalnodes.size(); i++) {
                        if ((stof(finalnodes[i]->gameNode.price) <= highball)) {
                            NeoFinal.push_back(finalnodes[i]);
                        }
                    }
                    finalnodes = NeoFinal;
                    for (int i = 0; i < finalnodes.size(); i++) {
                        this->root = Splay(finalnodes[i]);
                    }
                }
            }
        }

        if (achievements) {
            vector<splayNode*> NeoFinal;
            if (finalnodes.empty()) {
                finalnodes = AchievementSearch();
            }
            else {
                for (int i = 0; i < finalnodes.size(); i++) {
                    if (finalnodes[i]->gameNode.achievements != "0") {
                        NeoFinal.push_back(finalnodes[i]);
                    }
                }
                finalnodes = NeoFinal;
                for (int i = 0; i < finalnodes.size(); i++) {
                    this->root = Splay(finalnodes[i]);
                }
            }
        }





        vector<game> returnal;
        for (int i = 0; i < finalnodes.size(); i++) {
            returnal.push_back(finalnodes[i]->gameNode);
        }
        return returnal;
    }


    void FinalPrinter(vector<game> finalvector) {
        for (int i = 0; i < finalvector.size(); i++) {
            finalvector[i].display();
            cout << endl << endl << endl;
        }
    }





    void PrintBFS() {
        queue<splayNode*> splayers;
        splayers.push(this->root);
        while (!splayers.empty()) {
            cout << "BFS: " << splayers.front()->ID << " ";
            if (splayers.front()->leftchild != nullptr) {
                splayers.push(splayers.front()->leftchild);
            }
            if (splayers.front()->rightchild != nullptr) {
                splayers.push(splayers.front()->rightchild);
            }
            splayers.pop();
        }
        cout << endl;
    }


    void printInorder();

    void insert(string appID, string name,
        string releaseDate,
        string estimatedPlayers,
        string price,
        string description,
        vector<string> supportedLanguages,
        string windowsCompatible,
        string macCompatible,
        string linuxCompatible,
        string positiveReviews,
        string negativeReviews,
        string achievements,
        string recommendations,
        vector<string> developers,
        vector<string> genres,
        vector<string> tags);

    void IDsearch(int key) {
        SearchIDhelp(key, this->root);
    }

    void Namesearch(string nombre) {
        if (!Namesearchhelp(nombre, this->root)) {  //if the namesearch returns false then it was unsuccessful but the input was valid

        }
    }

    void printPreorder() {
        helperPreorder(this->root);
        cout << endl;
    }

    void printPostorder() {
        helperPostorder(this->root);
        cout << endl;
    }

    void printLevelCount() {
        cout << LevelCounterhelp(this->root);
        cout << endl;
    }


    //~Splaytree();

    //end of class
};

void Splaytree::SearchIDhelp(int key, splayNode* helpRoot) { //Complexity should be Log(n) as it searches by
    if (helpRoot == nullptr) {
        cout << "unsuccessful" << endl;
    }
    else if (helpRoot->ID == key) { //if correct
        cout << helpRoot->NAME << endl;
    }
    else if (key < helpRoot->ID) {  //this two functions are the recursions
        SearchIDhelp(key, helpRoot->leftchild);
    }
    else if (key > helpRoot->ID) {
        SearchIDhelp(key, helpRoot->rightchild);
    }
}


Splaytree::splayNode* Splaytree::Searchpredecessor(int key, splayNode* helpRoot) { //Complexity should be Log(n) as it searches by ID, simply finds the node before the node with the input key
    if (helpRoot == nullptr) { //base case
        return nullptr;
    }
    if ((helpRoot->leftchild == nullptr) and (helpRoot->rightchild == nullptr)) {
        if (helpRoot->ID == key) {
            return helpRoot;
        }
        return nullptr;
    }

    else if (key < helpRoot->ID) {
        if (helpRoot->leftchild->ID == key) {
            return helpRoot;
        }
        return Searchpredecessor(key, helpRoot->leftchild);
    }
    else if (key > helpRoot->ID) {
        if (helpRoot->rightchild->ID == key) {
            return helpRoot;
        }
        return Searchpredecessor(key, helpRoot->rightchild);
    }
    return nullptr;
}


bool Splaytree::Namesearchhelp(string nombre, Splaytree::splayNode* helpRoot) { //preorder search, this is bool to help me check for Name not existing
    bool found = false;
    if (helpRoot == nullptr) { // Root
        return false; // no need to execute further code as there should be no children
    }
    else if (helpRoot->NAME == nombre) {
        cout << helpRoot->ID << endl;
        found = true;
    }
    if (Namesearchhelp(nombre, helpRoot->leftchild)) { // Left
        found = true;
    }
    if (Namesearchhelp(nombre, helpRoot->rightchild)) { // right
        found = true;
    }
    return found;
}

//to help for printInorder printing
void Splaytree::helperInorder(Splaytree::splayNode* helpRoot, bool& comma)     //The main printing function, the other two are just variants of this
{
    if (helpRoot == nullptr)
        return;
    else
    {
        helperInorder(helpRoot->leftchild, comma);//first goes down the left
        //cout << helpRoot->ID; //Used to see the ID's too

        if (!comma) { // this is set up to take care of the no comma when starting
            cout << helpRoot->NAME;
            comma = true;
        }
        else if (comma) {
            cout << ", " << helpRoot->NAME;  //after all the nodes to left are printed, this node is then printed
        }
        helperInorder(helpRoot->rightchild, comma); //right is last
    }
}


void Splaytree::helperPreorder(Splaytree::splayNode* helpRoot)
{
    if (helpRoot == nullptr)
        return;
    else
    {
        //cout << helpRoot->ID; //Used to see the ID's too
        if (helpRoot->ID != this->root->ID) {   //for the comma exception
            cout << ", " << helpRoot->NAME;
        }
        else
            cout << helpRoot->NAME;
        helperPreorder(helpRoot->leftchild);    //basic recursion
        helperPreorder(helpRoot->rightchild);
    }
}


void Splaytree::helperPostorder(Splaytree::splayNode* helpRoot)   //see Preorder, same thing, different order
{
    if (helpRoot == nullptr)
        return;
    else
    {
        helperPostorder(helpRoot->leftchild);
        helperPostorder(helpRoot->rightchild);
        //cout << helpRoot->ID;         //Used to see the ID's too
        if (helpRoot->ID != this->root->ID) {
            cout << helpRoot->NAME << ", ";
        }
        else
            cout << helpRoot->NAME;
    }
}

//to help with insertion
Splaytree::splayNode* Splaytree::helperInsert(splayNode*& Splayer, splayNode* parent, splayNode* helpRoot, string appID, string name,
    string releaseDate,
    string estimatedPlayers,
    string price,
    string description,
    vector<string> supportedLanguages,
    string windowsCompatible,
    string macCompatible,
    string linuxCompatible,
    string positiveReviews,
    string negativeReviews,
    string achievements,
    string recommendations,
    vector<string> developers,
    vector<string> genres,
    vector<string> tags)
{
    if (helpRoot == nullptr) {      //found where to insert
        Splayer = new splayNode(parent, appID, name, releaseDate, estimatedPlayers, price, description, supportedLanguages, windowsCompatible, macCompatible, linuxCompatible, positiveReviews, negativeReviews, achievements, recommendations, developers, genres, tags);
        return Splayer;
    }
    else if (stoi(appID) < helpRoot->ID) {  //recursively going down
        helpRoot->leftchild = helperInsert(Splayer, helpRoot, helpRoot->leftchild, appID, name, releaseDate, estimatedPlayers, price, description, supportedLanguages, windowsCompatible, macCompatible, linuxCompatible, positiveReviews, negativeReviews, achievements, recommendations, developers, genres, tags);
    }
    else if (stoi(appID) > helpRoot->ID) {
        helpRoot->rightchild = helperInsert(Splayer, helpRoot, helpRoot->rightchild, appID, name, releaseDate, estimatedPlayers, price, description, supportedLanguages, windowsCompatible, macCompatible, linuxCompatible, positiveReviews, negativeReviews, achievements, recommendations, developers, genres, tags);
    }
    return helpRoot;
}


void Splaytree::printInorder()
{
    bool comma = false;
    helperInorder(this->root, comma);
    cout << endl;
}


void Splaytree::insert(string appID, string name,
    string releaseDate,
    string estimatedPlayers,
    string price,
    string description,
    vector<string> supportedLanguages,
    string windowsCompatible,
    string macCompatible,
    string linuxCompatible,
    string positiveReviews,
    string negativeReviews,
    string achievements,
    string recommendations,
    vector<string> developers,
    vector<string> genres,
    vector<string> tags)
{
    splayNode* splayer;
    this->root = helperInsert(splayer, this->root, this->root, appID, name, releaseDate, estimatedPlayers, price, description, supportedLanguages, windowsCompatible, macCompatible, linuxCompatible, positiveReviews, negativeReviews, achievements, recommendations, developers, genres, tags);
    this->root = Splay(splayer);
}


int Splaytree::LevelCounterhelp(splayNode* helpRoot) {
    int lvlcountleft;
    int lvlcountright;
    if (helpRoot == nullptr) {
        return 0;
    }
    else {
        lvlcountleft = LevelCounterhelp(helpRoot->leftchild);   // goes down each subtree
        lvlcountright = LevelCounterhelp(helpRoot->rightchild);
        if (lvlcountleft >= lvlcountright) {
            return lvlcountleft + 1;
        }
        else {
            return lvlcountright + 1;
        }
    }
}


Splaytree::splayNode* Splaytree::Splay(Splaytree::splayNode* helpRoot) {
    if (helpRoot->parent == nullptr) {
        return helpRoot;
    }
    if (helpRoot->parent->parent == nullptr) {  //zig case
        if (helpRoot == helpRoot->parent->leftchild) {
            helpRoot = Zig(this->root);
            return helpRoot;
        }
        else {
            helpRoot = Zag(this->root);
            return helpRoot;
        }

    }
    else if (helpRoot->parent->parent->leftchild == helpRoot->parent) {
        if (helpRoot->parent->leftchild == helpRoot) {
            helpRoot = Zig(Zig(helpRoot->parent->parent));



        }
        else {
            helpRoot = Zig(Zag(helpRoot->parent)->parent);


        }
    }
    else {
        if (helpRoot->parent->rightchild == helpRoot) {
            helpRoot = Zag(Zag(helpRoot->parent->parent));

        }
        else {
            helpRoot = Zag(Zig(helpRoot->parent)->parent);
        }
    }
    return Splay(helpRoot);

}


Splaytree::splayNode* Splaytree::Zig(splayNode* parent) {   //rightrotate
    splayNode* child = parent->leftchild;
    parent->leftchild = child->rightchild;
    if (child->rightchild != nullptr) {
        child->rightchild->parent = parent;
    }
    child->rightchild = parent;
    if (parent->parent != nullptr) {
        if (parent == parent->parent->leftchild) {
            parent->parent->leftchild = child;
        }
        else {
            parent->parent->rightchild = child;
        }
    }
    child->parent = parent->parent;
    parent->parent = child;


    return child;
}       //The different rotations

Splaytree::splayNode* Splaytree::Zag(splayNode* parent) {   //leftrotate
    splayNode* child = parent->rightchild;
    parent->rightchild = child->leftchild;
    if (child->leftchild != nullptr) {
        child->leftchild->parent = parent;
    }
    child->leftchild = parent;
    if (parent->parent != nullptr) {
        if (parent == parent->parent->leftchild) {
            parent->parent->leftchild = child;
        }
        else {
            parent->parent->rightchild = child;
        }
    }
    child->parent = parent->parent;
    parent->parent = child;



    return child;
}


void Splaytree::Inordertraversal(splayNode* helpRoot, int N, int& counter, int& IDresult) {
    if (counter - 1 >= N or helpRoot == nullptr) { // for no nodes or already found the result
        return;
    }
    Inordertraversal(helpRoot->leftchild, N, counter, IDresult);       //traverse left
    counter += 1;       //add to count

    if (N == counter - 1) {
        IDresult = helpRoot->ID;
        return;
    }
    Inordertraversal(helpRoot->rightchild, N, counter, IDresult);
}

/*
Splaytree::~Splaytree() {
    Destroyer(this->root);
}
*/

/*
void Splaytree::Destroyer(splayNode *helpRoot) {    //destructor function
    if(helpRoot == nullptr)
        return;
    else
    {
        Destroyer(helpRoot->leftchild);
        Destroyer(helpRoot->rightchild);
        Destroyer(helpRoot->parent);
        delete helpRoot;
        return;
    }
}
*/


bool Checkname(string name) {
    for (char c : name) {
        if (!isalpha(c) && !isspace(c)) {
            return false;
        }
    }
    return true;
}

bool CheckID(string ID) {
    if (ID.size() != 8) {
        return false;
    }
    for (char c : ID) {
        if (!isdigit(c)) {
            return false;
        }
    }
    return true;
}









// end of defintions


string SH = "";
vector<string> VH = { "devGuy", "gunter" };
vector<string> altv = { "Production" };
vector<string> shamogus = { "gunter" };
vector<string> emptier;




int main()
{

    string dataStructure;
    cout << "Choose Data Structure (0 for Min-Heap, 1 for Splay Tree): " << endl;
    getline(cin, dataStructure);
    if (dataStructure == "0") {
        cout << "Loading Min-Heap: " << endl;

        high_resolution_clock::time_point start = high_resolution_clock::now(); //Start Timer

        //CSVReader reader("../CSV_FILES/TestProjectBook.csv"); //Shortened Dataset
        CSVReader reader("../CSV_FILES/games2.csv"); //Full Dataset

        vector<string> vectorOfAppIDs; //Initialize all vectors that will be used for datapoints
        vector<string> vectorOfNames;
        vector<string> vectorOfReleaseDates;
        vector<string> vectorOfEstimatedPlayers;
        vector<string> vectorOfPrices;
        vector<string> vectorOfDescriptions;
        vector<string> vectorOfWindowsCompatibility;
        vector<string> vectorOfMacCompatibility;
        vector<string> vectorOfLinuxCompatibility;
        vector<string> vectorOfPositiveReviews;
        vector<string> vectorOfNegativeReviews;
        vector<string> vectorOfAchievements;
        vector<string> vectorOfRecommendations;
        vector<string> vectorOfSupportedLanguagesUnparsed;
        vector<string> vectorOfDevelopersUnparsed;
        vector<string> vectorOfGenresUnparsed;
        vector<string> vectorOfTagsUnparsed;


        vector<vector<string>> vectorOfSupportedLanguages;
        vector<vector<string>> vectorOfDevelopers;
        vector<vector<string>> vectorOfGenres;
        vector<vector<string>> vectorOfTags;


        vector<game*> games;

        for (auto& row : reader) {
            vectorOfAppIDs.push_back(row["AppID"].get<string>());
            vectorOfNames.push_back(row["Name"].get<string>());
            vectorOfReleaseDates.push_back(row["Release date"].get<string>());
            vectorOfEstimatedPlayers.push_back(row["Estimated owners"].get<string>());
            vectorOfPrices.push_back(row["Price"].get<string>());
            vectorOfDescriptions.push_back(row["About the game"].get<string>());
            vectorOfWindowsCompatibility.push_back(row["Windows"].get<string>());
            vectorOfMacCompatibility.push_back(row["Mac"].get<string>());
            vectorOfLinuxCompatibility.push_back(row["Linux"].get<string>());
            vectorOfPositiveReviews.push_back(row["Positive"].get<string>());
            vectorOfNegativeReviews.push_back(row["Negative"].get<string>());
            vectorOfAchievements.push_back(row["Achievements"].get<string>());
            vectorOfRecommendations.push_back(row["Recommendations"].get<string>());
            vectorOfSupportedLanguagesUnparsed.push_back(row["Supported languages"].get<string>()); //Unparsed
            vectorOfDevelopersUnparsed.push_back(row["Developers"].get<string>()); //Unparsed
            vectorOfGenresUnparsed.push_back(row["Genres"].get<string>()); //Unparsed
            vectorOfTagsUnparsed.push_back(row["Tags"].get<string>()); //Unparsed
        }

        vector<vector<string>> allLanguagesParsed;

        for (int i = 0; i < vectorOfSupportedLanguagesUnparsed.size(); i++) { //Parse Supported Languages
            vector<string> stringSeperator;
            stringstream newString(vectorOfSupportedLanguagesUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allLanguagesParsed.push_back(stringSeperator);
        }

        for (int i = 0; i < allLanguagesParsed.size(); i++) {
            for (int j = 0; j < allLanguagesParsed.at(i).size(); j++) {
                if (allLanguagesParsed.at(i).at(j).at(0) == ' ') {
                    allLanguagesParsed.at(i).at(j).erase(allLanguagesParsed.at(i).at(j).begin()); //Delete spaces in the first character
                }
                for (int k = 0; k < allLanguagesParsed.at(i).at(j).size(); k++) {
                    if (allLanguagesParsed.at(i).at(j).at(k) == '[' || allLanguagesParsed.at(i).at(j).at(k) == ']' || allLanguagesParsed.at(i).at(j).at(k) == '\'') { //Delete other characters
                        allLanguagesParsed.at(i).at(j).erase(allLanguagesParsed.at(i).at(j).begin() + k);
                        k--;
                    }
                }
            }
        }

        vector<vector<string>> allDevelopersParsed;
        vector<vector<string>> allGenresParsed;
        vector<vector<string>> allTagsParsed;


        for (int i = 0; i < vectorOfDevelopersUnparsed.size(); i++) { //Parse Supported Developers
            vector<string> stringSeperator;
            stringstream newString(vectorOfDevelopersUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allDevelopersParsed.push_back(stringSeperator);
        }

        for (int i = 0; i < vectorOfGenresUnparsed.size(); i++) { //Parse Supported Genres
            vector<string> stringSeperator;
            stringstream newString(vectorOfGenresUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allGenresParsed.push_back(stringSeperator);
        }

        for (int i = 0; i < vectorOfTagsUnparsed.size(); i++) { //Parse Supported Tags
            vector<string> stringSeperator;
            stringstream newString(vectorOfTagsUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allTagsParsed.push_back(stringSeperator);
        }




        game* root = nullptr;

        game* gameArray[70428]; //Fixed size for a fixed database

        for (int i = 0; i < 70428; i++) { //Create all new game nodes and construct heap
            game* newGame = new game(vectorOfAppIDs.at(i), vectorOfNames.at(i), vectorOfReleaseDates.at(i), vectorOfEstimatedPlayers.at(i), vectorOfPrices.at(i), vectorOfDescriptions.at(i), vectorOfWindowsCompatibility.at(i), vectorOfMacCompatibility.at(i), vectorOfLinuxCompatibility.at(i), vectorOfPositiveReviews.at(i), vectorOfNegativeReviews.at(i), vectorOfAchievements.at(i), vectorOfRecommendations.at(i), allLanguagesParsed.at(i), allDevelopersParsed.at(i), allGenresParsed.at(i), allTagsParsed.at(i));
            gameArray[i] = newGame;
            int child = i;
            int parent = (i - 1) / 2;
            while (parent >= 0 && gameArray[parent]->appID > gameArray[child]->appID) {
                game* tempGame = gameArray[child];
                gameArray[child] = gameArray[parent];   //Swap
                gameArray[parent] = tempGame;
                child = parent;
                parent = (child - 1) / 2;
            }
        }
        /*for (int i = 0; i < vectorOfAppIDs.size(); i++) {
            gameArray[i]->display();
            cout << endl;
        }*/
        high_resolution_clock::time_point stop = high_resolution_clock::now(); //End timer and display run time
        duration<float> totalTime = duration_cast<duration<float>>(stop - start);
        cout << totalTime.count() << " seconds." << endl;

        //Begin User Input

        while (1 == 1) {
            string token;
            string command;
            istringstream inputStream;
            cout << "Enter Command \"Search\" to search: " << endl;
            getline(cin, command);
            inputStream.str(command);

            getline(inputStream, token, ' ');
            /*    if (token == "DeveloperSearch") {
                    getline(inputStream, token);

                    for (int i = 0; i < 70428; i++) {                                                                                       //Display all games by a developer
                        for (int developers = 0; developers < gameArray[i]->developers.size(); developers++) {
                            if (gameArray[i]->developers.at(developers) == token) {
                                gameArray[i]->display();
                                cout << endl << endl;
                            }
                        }
                    }

                }*/
            if (token == "Search") {
                float priceMax = -1.00f;
                cout << "Price Range: Enter 1 for free games only, 2 for games less than or equal to $5.00, 3 for games less than or equal to $20.00, 4 for games less than or equal to $60.00, and 5 for all games." << endl;  //Enter Price Range
                getline(cin, command);
                if (command == "1") {
                    priceMax = 0.00f;
                }
                else if (command == "2") {
                    priceMax = 5.00f;
                }
                else if (command == "3") {
                    priceMax = 20.00f;
                }
                else if (command == "4") {
                    priceMax = 60.00f;
                }
                else if (command == "5") {
                    priceMax = 99999.99f;
                }

                string system = "";
                cout << "Please Input System (Windows, Mac, Linux):" << endl;
                getline(cin, command);
                system = command;

                string language = "";
                cout << "Please Enter Language:" << endl;
                getline(cin, command);
                language = command;

                bool achievments = false;
                cout << "Achievements: Enter 1 for only games with achievments, Enter 2 for all games" << endl;
                getline(cin, command);
                if (command == "1") {
                    achievments = true;
                }
                else {
                    achievments = false;
                }

                string developer = "";
                bool developerNeeded = false;
                cout << "Developer: Please enter 0 if you do not wish to sort by developer. Otherwise, type in developer name:" << endl;
                getline(cin, command);
                if (command == "0") {
                    developerNeeded = false;
                }
                else {
                    developerNeeded = true;
                    developer = command;
                }

                vector<string> genres;
                cout << "Enter all genres for your game in the format (Action,Adventure,Indie) without parantheses; Leave Blank for no Genres:" << endl;
                getline(cin, command);
                istringstream genreStream;
                genreStream.str(command);
                string token;
                while (getline(genreStream, token, ',')) {
                    genres.push_back(token);
                }

                vector<string> tags;
                cout << "Enter all tags for your game in the format (Competitive,Multiplayer,Farming Sim) without parantheses; Leave Blank for no Tags:" << endl;
                getline(cin, command);
                istringstream tagStream;
                tagStream.str(command);
                string token2;
                while (getline(tagStream, token2, ',')) {
                    tags.push_back(token2);
                }

                cout << endl << "Beginning Search" << endl;

                for (int i = 0; i < 70428; i++) {   //Final Search
                    if (stof(gameArray[i]->price) <= priceMax) {

                        if (system == "Windows") {                                  //Filter by compatibility
                            if (gameArray[i]->windowsCompatible == "FALSE") {
                                continue;
                            }
                        }
                        else if (system == "Mac") {
                            if (gameArray[i]->macCompatible == "FALSE") {
                                continue;
                            }
                        }
                        else if (system == "Linux") {
                            if (gameArray[i]->linuxCompatible == "FALSE") {
                                continue;
                            }
                        }

                        bool languageFound = false;
                        for (int languageSearch = 0; languageSearch < gameArray[i]->supportedLanguages.size(); languageSearch++) {    //Filter by Language
                            if (gameArray[i]->supportedLanguages.at(languageSearch) == language) {
                                languageFound = true;
                            }
                        }
                        if (languageFound == false) {
                            continue;
                        }


                        if (achievments == true && stoi(gameArray[i]->achievements) <= 0) { //Filter by Achievements
                            continue;
                        }

                        bool developerFound = false;
                        if (developerNeeded == true) {
                            for (int developerSearch = 0; developerSearch < gameArray[i]->developers.size(); developerSearch++) { //Filter by Developer
                                if (gameArray[i]->developers.at(developerSearch) == developer) {
                                    developerFound = true;
                                }
                            }
                        }
                        else {
                            developerFound = true;
                        }

                        if (developerFound == false) {
                            continue;
                        }

                        bool genreFailed = false;
                        for (int genreSearch = 0; genreSearch < genres.size(); genreSearch++) {         //Filter by Genre
                            bool currentGenreFound = false;
                            for (int currentGenre = 0; currentGenre < gameArray[i]->genres.size(); currentGenre++) {
                                if (gameArray[i]->genres.at(currentGenre) == genres.at(genreSearch)) {
                                    currentGenreFound = true;
                                }
                            }
                            if (currentGenreFound == false) {
                                genreFailed = true;
                            }
                        }

                        if (genreFailed == true) {
                            continue;
                        }


                        bool tagFailed = false;
                        for (int tagSearch = 0; tagSearch < tags.size(); tagSearch++) {         //Filter by Tags
                            bool currentTagFound = false;
                            for (int currentTag = 0; currentTag < gameArray[i]->tags.size(); currentTag++) {
                                if (gameArray[i]->tags.at(currentTag) == tags.at(tagSearch)) {
                                    currentTagFound = true;
                                }
                            }
                            if (currentTagFound == false) {
                                tagFailed = true;
                            }
                        }

                        if (tagFailed == true) {
                            continue;
                        }



                        gameArray[i]->display();
                        cout << endl << endl;
                    }
                }

                cout << "Search Has Ended" << endl;


            }





        }

    } else if (dataStructure == "1") {
        cout << "Loading Splay Tree: " << endl;
        Splaytree SplayerTree;
        high_resolution_clock::time_point start = high_resolution_clock::now(); //Start Timer

        //CSVReader reader("../CSV_FILES/TestProjectBook.csv"); //Shortened Dataset
        CSVReader reader("../CSV_FILES/games2.csv"); //Full Dataset

        vector<string> vectorOfAppIDs; //Initialize all vectors that will be used for datapoints
        vector<string> vectorOfNames;
        vector<string> vectorOfReleaseDates;
        vector<string> vectorOfEstimatedPlayers;
        vector<string> vectorOfPrices;
        vector<string> vectorOfDescriptions;
        vector<string> vectorOfWindowsCompatibility;
        vector<string> vectorOfMacCompatibility;
        vector<string> vectorOfLinuxCompatibility;
        vector<string> vectorOfPositiveReviews;
        vector<string> vectorOfNegativeReviews;
        vector<string> vectorOfAchievements;
        vector<string> vectorOfRecommendations;
        vector<string> vectorOfSupportedLanguagesUnparsed;
        vector<string> vectorOfDevelopersUnparsed;
        vector<string> vectorOfGenresUnparsed;
        vector<string> vectorOfTagsUnparsed;


        vector<vector<string>> vectorOfSupportedLanguages;
        vector<vector<string>> vectorOfDevelopers;
        vector<vector<string>> vectorOfGenres;
        vector<vector<string>> vectorOfTags;


        vector<game*> games;

        for (auto& row : reader) {
            vectorOfAppIDs.push_back(row["AppID"].get<string>());
            vectorOfNames.push_back(row["Name"].get<string>());
            vectorOfReleaseDates.push_back(row["Release date"].get<string>());
            vectorOfEstimatedPlayers.push_back(row["Estimated owners"].get<string>());
            vectorOfPrices.push_back(row["Price"].get<string>());
            vectorOfDescriptions.push_back(row["About the game"].get<string>());
            vectorOfWindowsCompatibility.push_back(row["Windows"].get<string>());
            vectorOfMacCompatibility.push_back(row["Mac"].get<string>());
            vectorOfLinuxCompatibility.push_back(row["Linux"].get<string>());
            vectorOfPositiveReviews.push_back(row["Positive"].get<string>());
            vectorOfNegativeReviews.push_back(row["Negative"].get<string>());
            vectorOfAchievements.push_back(row["Achievements"].get<string>());
            vectorOfRecommendations.push_back(row["Recommendations"].get<string>());
            vectorOfSupportedLanguagesUnparsed.push_back(row["Supported languages"].get<string>()); //Unparsed
            vectorOfDevelopersUnparsed.push_back(row["Developers"].get<string>()); //Unparsed
            vectorOfGenresUnparsed.push_back(row["Genres"].get<string>()); //Unparsed
            vectorOfTagsUnparsed.push_back(row["Tags"].get<string>()); //Unparsed
        }

        vector<vector<string>> allLanguagesParsed;

        for (int i = 0; i < vectorOfSupportedLanguagesUnparsed.size(); i++) { //Parse Supported Languages
            vector<string> stringSeperator;
            stringstream newString(vectorOfSupportedLanguagesUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allLanguagesParsed.push_back(stringSeperator);
        }

        for (int i = 0; i < allLanguagesParsed.size(); i++) {
            for (int j = 0; j < allLanguagesParsed.at(i).size(); j++) {
                if (allLanguagesParsed.at(i).at(j).at(0) == ' ') {
                    allLanguagesParsed.at(i).at(j).erase(allLanguagesParsed.at(i).at(j).begin()); //Delete spaces in the first character
                }
                for (int k = 0; k < allLanguagesParsed.at(i).at(j).size(); k++) {
                    if (allLanguagesParsed.at(i).at(j).at(k) == '[' || allLanguagesParsed.at(i).at(j).at(k) == ']' || allLanguagesParsed.at(i).at(j).at(k) == '\'') { //Delete other characters
                        allLanguagesParsed.at(i).at(j).erase(allLanguagesParsed.at(i).at(j).begin() + k);
                        k--;
                    }
                }
            }
        }

        vector<vector<string>> allDevelopersParsed;
        vector<vector<string>> allGenresParsed;
        vector<vector<string>> allTagsParsed;


        for (int i = 0; i < vectorOfDevelopersUnparsed.size(); i++) { //Parse Supported Developers
            vector<string> stringSeperator;
            stringstream newString(vectorOfDevelopersUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allDevelopersParsed.push_back(stringSeperator);
        }

        for (int i = 0; i < vectorOfGenresUnparsed.size(); i++) { //Parse Supported Genres
            vector<string> stringSeperator;
            stringstream newString(vectorOfGenresUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allGenresParsed.push_back(stringSeperator);
        }

        for (int i = 0; i < vectorOfTagsUnparsed.size(); i++) { //Parse Supported Tags
            vector<string> stringSeperator;
            stringstream newString(vectorOfTagsUnparsed.at(i));
            string line;
            while (getline(newString, line, ',')) {
                stringSeperator.push_back(line);
            }
            allTagsParsed.push_back(stringSeperator);
        }
        /*
        for (int i = 0; i < vectorOfAppIDs.size(); i++) { //Create all new game nodes
            game* newGame = new game(vectorOfAppIDs.at(i), vectorOfNames.at(i), vectorOfReleaseDates.at(i), vectorOfEstimatedPlayers.at(i), vectorOfPrices.at(i), vectorOfDescriptions.at(i), vectorOfWindowsCompatibility.at(i), vectorOfMacCompatibility.at(i), vectorOfLinuxCompatibility.at(i), vectorOfPositiveReviews.at(i), vectorOfNegativeReviews.at(i), vectorOfAchievements.at(i), vectorOfRecommendations.at(i), allLanguagesParsed.at(i), allDevelopersParsed.at(i), allGenresParsed.at(i), allTagsParsed.at(i));
            games.push_back(newGame);
        }
         */ //for og testing

        for (int i = 0; i < vectorOfAppIDs.size(); i++) {
            SplayerTree.insert(vectorOfAppIDs.at(i), vectorOfNames.at(i), vectorOfReleaseDates.at(i), vectorOfEstimatedPlayers.at(i), vectorOfPrices.at(i), vectorOfDescriptions.at(i), allLanguagesParsed.at(i), vectorOfWindowsCompatibility.at(i), vectorOfMacCompatibility.at(i), vectorOfLinuxCompatibility.at(i), vectorOfPositiveReviews.at(i), vectorOfNegativeReviews.at(i), vectorOfAchievements.at(i), vectorOfRecommendations.at(i), allDevelopersParsed.at(i), allGenresParsed.at(i), allTagsParsed.at(i));
        }

        /*
        for (int i = 0; i < games.size(); i++) { //Display all games (for testing)
            games.at(i)->display();
            cout << endl << endl;
        }
        */
        // comment line for commenting out main
        high_resolution_clock::time_point stop = high_resolution_clock::now(); //End timer and display run time
        duration<float> totalTime = duration_cast<duration<float>>(stop - start);
        cout << totalTime.count() << " seconds." << endl;



        /*
        Splaytree Testertree;
        Testertree.insert("12", "12", SH, SH, SH, SH, VH, SH, SH, SH, SH, SH, SH, SH, altv, altv, altv);
        Testertree.insert("15", "15", SH, SH, SH, SH, VH, SH, SH, SH, SH, SH, SH, SH, VH, VH, VH);
            Testertree.insert("9", "9", SH, SH, SH, SH, VH, "TRUE", "TRUE", SH, SH, SH, SH, SH, shamogus, VH, VH);
            Testertree.insert("7", "7", SH, SH, SH, SH, VH, SH, SH, SH, SH, SH, SH, SH, VH, VH, VH);
            Testertree.insert("8", "8", SH, SH, SH, SH, VH, SH, SH, SH, SH, SH, SH, SH, VH, VH, VH);
        Testertree.printInorder();
        Testertree.PrintBFS();
        Testertree.printInorder();
        cout << endl << endl;
        cout << "Start" << endl;
        Testertree.FinalPrinter(Testertree.FinalSearcher(emptier, emptier, emptier, true, false, true, SH, SH, false));
        cout << "end";
         */




        while (1 == 1) {
            string token;
            string command;
            istringstream inputStream;
            cout << "Enter Command \"Search\" to search: " << endl;
            getline(cin, command);
            inputStream.str(command);

            getline(inputStream, token, ' ');
            /*    if (token == "DeveloperSearch") {
                    getline(inputStream, token);

                    for (int i = 0; i < 70428; i++) {                                                                                       //Display all games by a developer
                        for (int developers = 0; developers < gameArray[i]->developers.size(); developers++) {
                            if (gameArray[i]->developers.at(developers) == token) {
                                gameArray[i]->display();
                                cout << endl << endl;
                            }
                        }
                    }

                }*/

            if (token == "Search") {
                string pricer;
                string pricer2 = "";
                float priceMax = -1.00f;
                cout << "Price Range: Enter 1 for free games only, 2 for games less than or equal to $5.00, 3 for games less than or equal to $20.00, 4 for games less than or equal to $60.00, and 5 for all games." << endl;  //Enter Price Range
                getline(cin, command);
                if (command == "1") {
                    priceMax = 0.00f;
                    pricer = "0.00";
                }
                else if (command == "2") {
                    priceMax = 5.00f;
                    pricer = "5.00";
                }
                else if (command == "3") {
                    priceMax = 20.00f;
                    pricer = "20.00";
                }
                else if (command == "4") {
                    priceMax = 60.00f;
                    pricer = "60.00";
                }
                else if (command == "5") {
                    priceMax = 99999.99f;
                    pricer = "";
                }

                string system = "";
                cout << "Please Input System (Windows, Mac, Linux):" << endl;
                getline(cin, command);
                system = command;
                bool windows = false;
                bool mac = false;
                bool linux = false;
                if (command == "Windows") {
                    windows = true;
                }
                if (command == "Mac") {
                    mac = true;
                }
                if (command == "Linux") {
                    linux = true;
                }

                bool achievments = false;
                cout << "Achievements: Enter 1 for only games with achievements, Enter 2 for all games" << endl;
                getline(cin, command);
                if (command == "1") {
                    achievments = true;
                }
                else {
                    achievments = false;
                }

                string developer = "";
                bool developerNeeded = false;
                cout << "Developer: Please enter 0 if you do not wish to sort by developer. Otherwise, type in developer name:" << endl;
                getline(cin, command);
                vector<string> developers;
                if (command == "0") {
                    developerNeeded = false;
                }
                else {
                    developerNeeded = true;
                    developer = command;
                    developers.push_back(command);
                }


                vector<string> genres;
                cout << "Enter all genres for your game in the format (Action,Adventure,Indie) without parantheses; Leave Blank for no Genres:" << endl;
                getline(cin, command);
                istringstream genreStream;
                genreStream.str(command);
                string token;
                while (getline(genreStream, token, ',')) {
                    genres.push_back(token);
                }

                vector<string> tags;
                cout << "Enter all tags for your game in the format (Competitive,Multiplayer,Farming Sim) without parantheses; Leave Blank for no Tags:" << endl;
                getline(cin, command);
                istringstream tagStream;
                tagStream.str(command);
                string token2;
                while (getline(tagStream, token2, ',')) {
                    tags.push_back(token2);
                }

                cout << endl << "Beginning Search" << endl;

                SplayerTree.FinalPrinter(SplayerTree.FinalSearcher(tags, genres, developers, windows, linux, mac, pricer2, pricer, achievments));


                cout << "Search Has Ended" << endl;


            }





        }




        
    }










    return 0;
}